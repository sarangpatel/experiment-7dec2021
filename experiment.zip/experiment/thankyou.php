<?php require_once('./php/db.php');  ?>
<?php 
function getRoundData($user_id,$max_rounds){
	global $mysqli;
	$sql = "select * from round_scores where user_id = $user_id  order by created_on desc limit $max_rounds";
	$result = $mysqli->query($sql);
	$row = array();
	if($result->num_rows > 0 ) {
		while( $rw = $result->fetch_assoc()) {
			$row[] = $rw;
		}
		usort($row, function ($x, $y) {
			if ($x === $y) {
				return 0;
			}
			return $x < $y ? -1 : 1;
		});

		return $row;
	}else{
		return $row;
	}

}
?>
<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Psychological Experiment - Thank You</title>
	</head>
	<style>
		body{
    width: 50%;
    margin: 0 auto;
    padding: 36px;
		}
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
	<body>
<div style  = "text-align:center">
	<img src = "./img/leader-thankyou.jpeg" />
</div>
<?php $rounds = getRoundData($_GET['user_id'], $_GET['max_rounds']); ?>
<?php //echo '<PRE>'; print_r($rounds); ?>
<table>
  <tr>
    <th>Round</th>
    <th>Score</th>
    <th>Submitted on</th>
  </tr>
  <?php $total = 0; foreach($rounds as $round){ $total += $round["score"]; ?>

  <tr>
    <td><?php echo $round['round_no']; ?></td>
    <td><?php echo $round['score']; ?></td>
    <td><?php echo $round['created_on']; ?></td>

  </tr>
  <?php } ?>

  <tr>
    <th  style = "text-align:right">Total Score</th>
	<th colspan= "2"><?php echo $total; ?></th>
 </tr>
 <tr>
	<th colspan= "3" style  = "text-align:left;padding:12px;">MTurk Code:  RT<?php echo $total; ?></th>
 </tr>

 <!--			<img src = "./img/thankyou.jpg" style="width:100%"> -->
	</body>
</html>