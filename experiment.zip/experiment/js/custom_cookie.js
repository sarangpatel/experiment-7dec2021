/* global moment, globalDateTimeFormat, globalDateFormat, globalTimeFormat */


//removeCookie('accessToken', '');
function removeCookie(cname, cval) {
    document.cookie = cname + "=" + cval + ";expires=Thu, 01 Jan 1970 00:00:00 UTC;path=/;";

}

//
function setCookie(cname, cvalue, seconds) {
    if (seconds == 0) {
        document.cookie = cname + "=" + cvalue + "; path=/";
    } else {
        var d = new Date();
        d.setTime(d.getTime() + (seconds * 1000)); //seconds * 1000 = miliseconds
        var expires = "expires=" + d.toUTCString();
        document.cookie = cname + "=" + cvalue + ";" + expires + "; path=/";
    }
}

function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for (var i = 0; i < ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0) == ' ') {
            c = c.substring(1);
        }
        if (c.indexOf(name) == 0) {
            return c.substring(name.length, c.length);
        }
    }
    return "";
}


function datediff(first, second) {
    var date1 = new Date(first);
    var date2 = new Date(second);
    var Difference_In_Time = date2.getTime() - date1.getTime();
    var Difference_In_Days = Difference_In_Time / (1000 * 3600 * 24);
    return Math.round(Difference_In_Days);
}

