function game(){
	var totalScore = $('#total-score').text();
	var coinsRemaining = parseInt(globalTotalCoins);
	$('#coins-remaining').text(coinsRemaining);
	$('#total-score').text(totalScore);
	if(globalStudyVariation == 3){
		globalRandomHeadTailOption = Math.floor(Math.random() * 2) === 0 ? 'Less than ' + globalNumberGame : 'Greater than ' + globalNumberGame ;
		$('.lbox > div').html(globalRandomHeadTailOption);
		if(globalRandomHeadTailOption == 'Less than ' + globalNumberGame)
		$('.rbox > div').html('Greater than ' + globalNumberGame);
		if(globalRandomHeadTailOption == 'Greater than ' + globalNumberGame)
		$('.rbox > div').html('Less than ' + globalNumberGame);
	}else{
		globalRandomHeadTailOption = Math.floor(Math.random() * 2) === 0 ? 'HEAD' : 'TAIL' ;
		$('.lbox > div').html(globalRandomHeadTailOption);
		if(globalRandomHeadTailOption == 'HEAD')
		$('.rbox > div').html('TAIL');
		if(globalRandomHeadTailOption == 'TAIL')
		$('.rbox > div').html('HEAD');
	}
	$('.main').click(function(){return false;}); //disabled mouse click

	//$("#textarea3").html('The next coin will be flipped in x seconds');
	//$("#textarea1").html('Your time was [y] miliseconds. Your Score ' + totalScore);
}





function initRound(withText=''){

	//if all round over
	if(globalTotalCoins <= 0){
		setCookie('completed_experiment','yes' , globalKeepLoggedIn);
		window.location.href = URL + 'thankyou.php';
		return false;
	}

	globalRoundObj = {};//reinitialize roundObj
	globalRoundObj.centerMouseTime = 0;
	globalRoundObj.coinFlipTimer = globalCoinFlippedIn; //coin will flip in X sec
	globalRoundObj.roundScore = 0;
	$('#coinResultCircle, #animcoin1Result, #animcoin2Result, #animcoin3Result').hide();
	//$('#coin').css('cursor', 'pointer'); // 'default' to revert
	console.log('flip timer id', globalRoundObj.coinFlippTimerId);

	/*if($("#coin:hover").length != 0){*/
		//console.log('COIN HOVER')
		//mouseEnterInMiddleBox();
	/*}else{*/
		if(withText != 'middle')
		$("#textarea1").html('Please place your cursor in the circle');
	
		if($("#textarea4").text() !== '')
		$("#textarea1").html('');
		
	/*}*/



	/*on each round randamzing not required
	globalRandomHeadTailOption = Math.floor(Math.random() * 2) === 0 ? 'HEAD' : 'TAIL' ;
	$('.lbox > div').html(globalRandomHeadTailOption);
	if(globalRandomHeadTailOption == 'HEAD')
	$('.rbox > div').html('TAIL');
	if(globalRandomHeadTailOption == 'TAIL')
	$('.rbox > div').html('HEAD');*/
	/** on each round randamzing not required  */

	//$("#textarea3").html('The next coin will be flipped in ' + globalCoinFlippedIn + ' seconds');

}


function checkRoundTimeout(){
		
	if(typeof globalRoundObj.roundTimeoutTimer === 'undefined'){
		globalRoundObj.roundTimeoutTimer = setInterval(function(){
			var timeoutDifference = Math.round((new Date().getTime()-globalRoundObj.coinFlipResult)/1000);
			if(timeoutDifference >= globalRoundTimeout){
				alert('Timeout. Your score is 0.');
				//$("#textarea1").html('<div style ="color:#f79393">Timeout. Your Score is 0</div>');
				saveRoundData();
				globalTotalCoins -= 1;
				clearInterval(globalRoundObj.roundTimeoutTimer);
				$('#coins-remaining').text(globalTotalCoins);
				initRound();
				/*setTimeout(() => {
					$("#textarea1").html('Please put your mouse in the center box');
					initRound();
				},1600);*/
			}
		}, 1000);
	}
}

function saveRoundData(){
	var roundData = globalRoundObj;
	roundData.user_id = getCookie('user_id');
	roundData.coinOptions = $('.lbox > div').text() + ',' + $('.rbox > div').text();
	console.log('roundData', roundData);
	//ajax post
	$.ajax({
		url:  PHPURL + 'save-experiment-data.php',
		type: "POST",
		data: roundData,
		dataType: "json",
	}).done(function (data) {
		console.log("success Round data", data);
	}).fail(function (jqXHR, exception) {
		console.log('Save Round Data Error:' + jqXHR.responseText);
	});
}

function hideScoreMsg(){
	$('#coins-remaining').text(globalTotalCoins);
	globalRoundObj = {};//reinitialize roundObj
	initRound();
	/*setTimeout(() => {
		initRound();
	},1200);*/
}

function showSecondAnimCoin(res){
	setTimeout(() => {
				console.log( "HOVER 2", $('#coin').is(':hover'));
				var animCoin3 = Math.random();
				var animCoin3Res =  animCoin3 <= 0.5 ? 'head' : 'tail';
				if(globalStudyVariation == 2 || globalStudyVariation == 3){
					animCoin3Res = 'black-circle';
				}
				if($('#coin').is(':hover')){
					$('#animcoin2Result').attr('src', `./img/${res}.png`);
					$('#animcoin2Result').show();
					showThirdAnimCoin(animCoin3Res);
				}else{
					initRound();
				}
	} , 1000);
}

function showThirdAnimCoin(res){
	setTimeout(() => {
		console.log( "HOVER 3", $('#coin').is(':hover'));
		if($('#coin').is(':hover')){
			$('#animcoin3Result').attr('src', `./img/${res}.png`);
			$('#animcoin3Result').show();
			showFinalCoinResult();
		}else{
			initRound();
		}
	} , 1000);
}

function showFinalCoinResult(){
	$('#coin').removeClass();
	console.log( "FINAL HOVER", $('#coin').is(':hover'));
	
	//$("#coin div:eq(1)").addClass('side-b');
	//$('#coin div:eq(0)').addClass('side-a');
	console.log('final flip');
	setTimeout(function(){
		if($('#coin').is(':hover')){
			if(globalStudyVariation == 3){
				var min = Math.ceil(1);
				var max = Math.floor(100);
				var numberResult = Math.floor(Math.random() * (max - min + 1)) + min;
				if(numberResult == globalNumberGame){
					numberResult = Math.floor(Math.random() * globalNumberGame); //
				}
				$('#coinResultCircle > div').text(numberResult);
				$('#coinResultCircle').show();
				if(numberResult > globalNumberGame)
					globalCoinFlipped = 'greater';
				else
					globalCoinFlipped = 'less';
				globalRoundObj.coinFlipResult = new Date().getTime(); //actually show flip result after 0.5 ie added 500 milisec
				checkRoundTimeout();
			}else{
				var flipResult = Math.random();
				if(flipResult <= 0.5){
					$('#coinResultCircle').attr('src', './img/head.png');
					$('#coinResultCircle').show();
					$('#coin').addClass('heads');
					globalCoinFlipped = 'head';
					console.log('it is head');
					globalRoundObj.coinFlipResult = new Date().getTime(); //actually show flip result after 0.5 ie added 500 milisec
					checkRoundTimeout();
				}else{
					$('#coinResultCircle').attr('src', './img/tail.png');
					$('#coinResultCircle').show();
					$('#coin').addClass('tails');
					globalCoinFlipped = 'tail';
					console.log('it is tails');
					globalRoundObj.coinFlipResult = new Date().getTime();
					checkRoundTimeout();
				}
			}
		}else{
			initRound();
		}
	}, 1000);

}

function flipCoin(){
	setTimeout(() => {
		console.log( "HOVER", $('#coin').is(':hover'));
		var animCoin1 = Math.random();
		var animCoin2 = Math.random();
		var animCoin1Res =  animCoin1 <= 0.5 ? 'head' : 'tail';
		var animCoin2Res =  animCoin2 <= 0.5 ? 'head' : 'tail';
		if(globalStudyVariation == 2 || globalStudyVariation == 3){
			animCoin1Res = 'black-circle';
			animCoin2Res = 'black-circle';
		}
	
		if($('#coin').is(':hover')){
			$('#animcoin1Result').attr('src', `./img/${animCoin1Res}.png`);
			$('#animcoin1Result').show();
			showSecondAnimCoin(animCoin2Res);
		}else{
			initRound();
		}
	} , 1000);
}

function startCoinFlippTimer(){
	console.log("coin will flip in ", globalRoundObj.coinFlipTimer);

	/*if(globalRoundObj.coinFlipTimer <= 0){
		clearInterval(globalRoundObj.coinFlippTimerId);
		return false;
		}*/

	if(typeof globalRoundObj.coinFlippTimerId === 'undefined'){
		//$("#textarea3").html('The next round will start in ' + globalRoundObj.coinFlipTimer + ' seconds');
		$("#textarea1").html('The next round will start in ' + globalRoundObj.coinFlipTimer + ' seconds');
		globalRoundObj.coinFlippTimerId = setInterval(function(){
			globalRoundObj.coinFlipTimer  = globalRoundObj.coinFlipTimer - 1;
			if(globalRoundObj.coinFlipTimer == 0){
				console.log('0 reached', globalRoundObj.coinFlippTimerId, 'timeer:' + globalRoundObj.coinFlipTimer );
				clearInterval(globalRoundObj.coinFlippTimerId);
				globalRoundObj.coinFlipTime = new Date().getTime();
				//$("#textarea3").html('');
				$("#textarea1").html('');
				flipCoin();
			}else{
				//$("#textarea3").html('The next round will start in ' + globalRoundObj.coinFlipTimer + ' seconds');
				$("#textarea1").html('The next round will start in ' + globalRoundObj.coinFlipTimer + ' seconds');
			}
		}, 1000);
	}

}

function calculateTotalScore(){
	let score = 0;
	let answerGiven = 0;
	if(typeof globalRoundObj.answerClickTime !== 'undefined'){
		answerGiven  = Math.round(globalRoundObj.answerClickTime - globalRoundObj.coinFlipResult);
		score = globalScoreBase - answerGiven;
	}
	if(score <= 0)score = 0;
	if(typeof globalRoundObj.roundScore !== 'undefined'){
		globalRoundObj.roundScore = globalRoundObj.roundScore + score;
	}else{
		globalRoundObj.roundScore = score;
	}
	globalTotalScore += globalRoundObj.roundScore;
	$("#textarea4").html('Your time was <span style = "color:#e43131">' + answerGiven +
	 ' </span> miliseconds. Your Score was <span style = "color:#e43131">' 	+ score + '</span>');
	
	 $('.roundscore-add').text('+ ' + score);
	setTimeout(() => $('.roundscore-add').text(''), 1500);
	
	setTimeout(() => {
		$("#textarea4").html('');
		if(!$('#coin').is(':hover'))
		$("#textarea1").html('Please place your cursor in the circle');
	}, 1500);
	$('#total-score').text(globalTotalScore);

}



function mouseEnterInMiddleBox(){
	console.log('mouseenter')
	$("#textarea1").html('');
	initRound('middle');
	//globalRoundObj.coinFlippTimerId = undefined;
	if(globalRoundObj.centerMouseTime === 0)
	globalRoundObj.centerMouseTime = new Date().getTime();
	startCoinFlippTimer();
}

function finalCoinNotFlipped(){
	if(!globalRoundObj.coinFlipResult){
		console.log('inside final coin not flipped',globalRoundObj.coinFlipResult);
		$("#textarea1").html('Please place your cursor in the circle');
		//$("#textarea3").html('');
		let coinFlippTimerId = globalRoundObj.coinFlippTimerId || null;
		if(coinFlippTimerId !== null)
		clearInterval(coinFlippTimerId);
		initRound();
	}
}

jQuery(document).ready(function($){
	game(); //init
	initRound();
	$('.wrapper').mouseover(function(e) {

		var left = e.pageX - $(this).offset().left;
		var top = e.pageY - $(this).offset().top;
		//console.log('mouse movements', left + 'x' + top)
	});

	$('#coin').mouseenter(function(e) {
		mouseEnterInMiddleBox();
	});

	$('#coin').mouseleave(function(e) {
		/*if(globalRoundObj.coinFlipTimer > 0){
			$("#textarea1").html('Please put your mouse in the center box');
			$("#textarea3").html('');

			let coinFlippTimerId = globalRoundObj.coinFlippTimerId || null;
			if(coinFlippTimerId !== null)
			clearInterval(coinFlippTimerId);
			initRound();
		}*/
			finalCoinNotFlipped();

			/*if(!globalRoundObj.coinFlipResult){
				console.log('inside final coin not flipped',globalRoundObj.coinFlipResult)
				$("#textarea1").html('Please place your cursor in the circle.');
				$("#textarea3").html('');
				let coinFlippTimerId = globalRoundObj.coinFlippTimerId || null;
				if(coinFlippTimerId !== null)
				clearInterval(coinFlippTimerId);
				initRound();
			}*/


	});

	


	$( ".rbox, .lbox" ).mouseenter(function(e) {
		var left = e.pageX - $(this).offset().left;
		var top = e.pageY - $(this).offset().top;
		console.log('mouseenter', left, top)
		globalRoundObj.answerCursorEnterTime = new Date().getTime();

		console.log('going', globalRoundObj.coinFlipResult);
		if(typeof globalRoundObj.coinFlipResult !== 'undefined'){ 
			console.log('result')
			var optionSelected = $(this).find('div').text();
			var left = e.pageX - $(this).offset().left ;
			var top = e.pageY - $(this).offset().top;
			var correctAnswerSelection;
			if(globalStudyVariation == 3){
				if(optionSelected.toLowerCase().indexOf(globalCoinFlipped.toLowerCase()) !== -1 )
					correctAnswerSelection = true;
				else
					correctAnswerSelection = false;
			}else{
				if(optionSelected.toLowerCase() == globalCoinFlipped.toLowerCase())
					correctAnswerSelection = true;
				else
					correctAnswerSelection = false;
			}
			if(correctAnswerSelection){
				console.log('CORRECT ANSWER' , left + 'x' + top);
				if(typeof globalRoundObj.roundTimeoutTimer !== 'undefined')
				clearInterval(globalRoundObj.roundTimeoutTimer);
				globalRoundObj.answerClickTime = new Date().getTime();
				globalRoundObj.correctAnswer = "yes";

				calculateTotalScore();
				saveRoundData();
				globalTotalCoins -= 1;

				hideScoreMsg(); //save round data in backend

			}else{
				console.log('Wrong aNSWER');
				globalRoundObj.answerClickTime = new Date().getTime();
				globalRoundObj.correctAnswer = "no";
				globalRoundObj.roundScore = 0; 

				if(typeof globalRoundObj.roundTimeoutTimer !== 'undefined')
				clearInterval(globalRoundObj.roundTimeoutTimer);
				$("#textarea4").html('Wrong answer given. Your Score is 0');
				setTimeout(() => {
					$("#textarea4").html('');
					if(!$('#coin').is(':hover'))
					$('#textarea1').html('Please place your cursor in the circle');
				}, 1500);
				saveRoundData();
				globalTotalCoins -= 1;

				hideScoreMsg(); //save round data in backend
			}

		}


	});


	$('.rbox, .lbox').click(function(e) {
/*		console.log('going', globalRoundObj.coinFlipResult);
		if(typeof globalRoundObj.coinFlipResult !== 'undefined'){ 
			console.log('result')
			var optionSelected = $(this).find('div').text();
			var left = e.pageX - $(this).offset().left ;
			var top = e.pageY - $(this).offset().top;
			if(optionSelected.toLowerCase() == globalCoinFlipped.toLowerCase()){
				console.log('CORRECT ANSWER' , left + 'x' + top);
				if(typeof globalRoundObj.roundTimeoutTimer !== 'undefined')
				clearInterval(globalRoundObj.roundTimeoutTimer);
				globalRoundObj.answerClickTime = new Date().getTime();
				globalRoundObj.correctAnswer = "yes";

				calculateTotalScore();
				saveRoundData();
				globalTotalCoins -= 1;

				hideScoreMsg(); //save round data in backend

			}else{
				console.log('Wrong aNSWER');
				globalRoundObj.answerClickTime = new Date().getTime();
				globalRoundObj.correctAnswer = "no";
				globalRoundObj.roundScore = 0; 

				if(typeof globalRoundObj.roundTimeoutTimer !== 'undefined')
				clearInterval(globalRoundObj.roundTimeoutTimer);
				$("#textarea1").html('Wrong answer given. Your Score is 0');
				saveRoundData();
				globalTotalCoins -= 1;

				hideScoreMsg(); //save round data in backend
			}

		}
	*/	
	});



	/*$( ".lbox" ).mousemove(function(e) {
		var left = e.pageX - $(this).offset().left ;
		var top = e.pageY - $(this).offset().top;
		console.log('mouseover', left, top)

	});

	$( ".lbox" ).mouseleave(function(e) {
		var left = e.pageX - $(this).offset().left ;
		var top = e.pageY - $(this).offset().top;
		console.log('mouseleave', left, top)

	});*/

})// jqueryReadu


