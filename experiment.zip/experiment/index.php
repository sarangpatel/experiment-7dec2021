<!DOCTYPE html>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
		<title>Psychological Experiment</title>
		<!-- CSS styling -->
		<link href="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/themes/black-tie/jquery-ui.css"
			type="text/css" rel="stylesheet" />
		<link href="./css/style.css" type="text/css" rel="stylesheet" />
		<!-- JS libraries -->
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js"></script>
		<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jqueryui/1.8.18/jquery-ui.min.js"></script>
		<script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/jquery-validate/1.19.2/jquery.validate.min.js"></script>
		<!-- additional JS script for controlling page -->
		<script type="text/javascript" src="./js/custom_cookie.js"></script>

	</head>
	<body>
		<!--- START: step1 -->
		<div id="step1" class="page-container ui-widget ui-widget-content ui-corner-all">
			<h3>Input ID:</h3>
			<p >Data from this assignment are being used for educational research purposes. 
				Please refrain from disclosing any identifiable information in this assignment. 
				Any identifiable information will be excluded from use in educational research purposes. 
				All data from minors will be excluded from use in educational research purposes. 
			</p>
			<p>Please input your MTurk ID:</p>
			<form id="mturkFrm" name="mturkFrm" >
				<div><input type="text"  name="mturk_id" /></div>
				<input type="hidden"  name="gmtsec" />
				<input type="hidden"  name="mousetype" value = "mouse" />
				<input type="hidden"  name="resolution" />
				<input type="hidden" name="browser" />
				<div class = "errorTxt"></div>
				<div class = "pad10" ><button type="submit" id="mturkFrmSubmitButton" value="submit">Submit</button></div>
			</form>
		</div>
		<!--- END: step1 -->


		<!--- START: step2 -->
		<div id="step2" class="page-container ui-widget ui-widget-content ui-corner-all">
			<h3 class = "head">Instructions:</h3>
			<p >This experiment is about analyzing reaction time of user. In this study, you will shown three boxes in a horizontal row. The box are leftbox, middle box and right box. After specified time, middle box will show coin image ( this can be either head or tail image). You have to click left box or right box based on the image shown on middle box. This step will repeated based on No. of Coins shown on top right corner. 
			</p>
			<form id="instructionFrm" name="instructionFrm" >
				<input type="hidden"  name="gmtsec" />
				<br />
				<button type="submit" id="instructionFrmSubmitButton" value="submit">Continue </button>
			</form>
		</div>
		<!--- END: step2 -->


		<!--- START: step3 -->
		<div id="step3" class="page-container ui-widget ui-widget-content ui-corner-all">
			<h3 class = "head">Test:</h3>
			<p >Answer below questions, so that we know you understand the study.</p>
			<!--<div class= "smalltext">You can select more than answer (if applies)</div>-->
			<form id="questionFrm" name="questionFrm" >
	
				<p >Question 1: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
				<div>
					<div><input type =  "radio" name = "answer[1][]"  value = "answer1" > Answer 1</div>
					<div><input type =  "radio" name = "answer[1][]" value = "answer2"> Answer 2</div>
					<div><input type =  "radio" name = "answer[1][]" value = "answer3"> Answer 3</div>
					<div><input type =  "radio" name = "answer[1][]" value = "answer4"> Answer 4</div>
				</div>
				<div id = "errorAns1"></div>
				<p >Question 2: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
				<div>
					<div><input type =  "radio" name = "answer[2][]" value = "answer1" > Answer 1</div>
					<div><input type =  "radio" name = "answer[2][]" value = "answer2"> Answer 2</div>
					<div><input type =  "radio" name = "answer[2][]" value = "answer3"> Answer 3</div>
					<div><input type =  "radio" name = "answer[2][]" value = "answer4"> Answer 4</div>
				</div>
				<div id = "errorAns2"></div>

				<p >Question 3: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum</p>
				<div>
					<div><input type =  "radio" name = "answer[3][]" value = "answer1" > Answer 1</div>
					<div><input type =  "radio" name = "answer[3][]" value = "answer2"> Answer 2</div>
					<div><input type =  "radio" name = "answer[3][]" value = "answer3"> Answer 3</div>
					<div><input type =  "radio" name = "answer[3][]" value = "alloftheabove"> All of the above</div>
				</div>
				<div id = "errorAns3"></div>

				<input type="hidden"  name="gmtsec" />
				<input type="hidden" name="user_id" />
				<br />
				<button type="submit" id="questionFrmSubmitButton" value="submit">Submit </button>
			</form>
		</div>
		<!--- END: step3 -->

		<!--- START: step4 CALIBRATION -->
		<div id="step4" class="page-container ui-widget ui-widget-content ui-corner-all">
			<h3 class = "head">Calibration: We first must calibrate your scren size.</h3>
			<p>Place your credit card against your screen and move the slider until the image is the same size as the credit card. </p>
				<div class="slider-wrapper">
					<div id="slider" class="sliders">
					</div>
				</div>
				<!-- This outputs the current estimated screen size, based on the size of the image -->
				<p class="center-stuff" style= "display:none">
					<strong>Your diagonal monitor size is: 
						<span id="diagsize"  class="head center-stuff"></span>
					</strong>
				</p>
				<form id="calibrateFrm" name="calibrateFrm" >
					<input type="hidden"  name="gmtsec" />
					<input type="hidden"  name="screen_size" />
					<input type="hidden"  name="pxpercm" />
					<input type="hidden"  name="user_id" />

					<button type="submit" id="calibrateFrmSubmitButton" value="submit">Submit </button>
				</form>
				<canvas id="myCanvas" width="600" height="600"></canvas>
		</div>
		<!--- END: step4 CALIBRATION -->


		<!--- START: step5 main study page -->
		<div id="step5" class="page-container game-page ui-widget ui-widget-content ui-corner-all">
			<div class="content" >
					<div class = "roundscore-add"></div>
					<div class = "topscore-right smalltext">Total Score: <span id = "total-score">00</span></div>
					<div class = "topscore-right smalltext">Round(s) Remaining: <span id = "rounds-remaining"></span></div>
					<div class = "topscore-right smalltext">Coin(s) Remaining: <span id = "coins-remaining"></span></div>
					<div style = "text-align:center;padding: 166px;display:none;" id = "roundMessage"></div>
			</div>


			<div class = "main">
				<?php if(empty($_GET['study']) || $_GET['study'] == 1 ) { ?>
				<div class ="anim-coin" id = "animcoin1"><img id = "animcoin1Result"  alt = "coin" width= "100%" style = "display:none;"></div>
				<div class ="anim-coin" id = "animcoin2"><img id = "animcoin2Result"  alt = "coin" width= "100%" style = "display:none;"></div>
				<div class ="anim-coin" id = "animcoin3"><img id = "animcoin3Result"  alt = "coin" width= "100%" style = "display:none;"></div>
				<?php } ?>
				<?php if(!empty($_GET['study']) && ($_GET['study'] == 2 || $_GET['study'] == 3) ) { ?>
					<div class = "anim-dots-container">
						<div class ="anim-dots" id = "animcoin1"><img id = "animcoin1Result"  alt = "coin" width= "100%" src = "./img/black-circle.png"></div>
						<div class ="anim-dots" id = "animcoin2"><img id = "animcoin2Result"  alt = "coin" width= "100%" src = "./img/black-circle.png"></div>
						<div class ="anim-dots" id = "animcoin3"><img id = "animcoin3Result"  alt = "coin" width= "100%" src = "./img/black-circle.png"></div>
					</div>
				<?php } ?>



				<div class="wrapper">

				  <div> 
				  		<div class = "lbox"><div class = "inner-box">HEAD</div></div>
				  </div>
				  <div>
				  	<div id="coin" class = "side-nuetral">
						  <?php if(!empty($_GET['study']) && $_GET['study'] == 3 ) { ?>
							<div id = "coinResultCircle" style = "display:none;" class= "center-number"><div></div></div>
					      <?php }else{ ?>
							<img id = "coinResultCircle"  alt = "coin" width= "100%" style = "display:none;">
						  <?php } ?>
					</div>
				  </div> 
				  <div> 
				 		<div class = "rbox"><div class = "inner-box">TAIL</div></div>
				   </div>
				</div>
			</div>

			<div class = "textmain">
				<div class="text1">
			  		<div id = "textarea1" >Please place your cursor in the circle.</div>
					  <!-- The next round will start in 5 sec. Your time was 33 miliseconds. Your score was 333 -->
				</div>
			</div>
			<div class="textmain" >
				<div class="text3">
				  		<div id = "textarea3" ></div>
				</div>
			</div>
			<div class="textmain" >
				<div class="text2">
				  		<div  id = "textarea4"></div>
				</div>
			</div>
		</div>
		<!--- END: step5 main study page -->

<?php if(!empty($_GET['study']) && $_GET['study'] == 2) { ?>
	<script>var globalStudyVariation = 2; </script>
<?php }else if(!empty($_GET['study']) && $_GET['study'] == 3){ ?>
	<script>var globalStudyVariation = 3; </script>
<?php }else{ ?>
	<script>var globalStudyVariation = 1; </script>
<?php } ?>
<script type="text/javascript" src="./js/login.js"></script>
<script type="text/javascript" src="./js/game.js"></script>

<script>
	//distance
	console.log("left", $('.lbox').offset());
	console.log("coin",  $('#coin').offset());

	console.log("right",$('.rbox').offset());

jQuery(document).ready(function($){

  /*$('#coin').on('click', function(){
    var flipResult = Math.random();
    globalRandomHeadTailOption = Math.floor(Math.random() * 2) === 0 ? 'HEAD' : 'TAIL' ;
    $('.lbox > div').html(globalRandomHeadTailOption);

    if(globalRandomHeadTailOption == 'HEAD')
    $('.rbox > div').html('TAIL');

    if(globalRandomHeadTailOption == 'TAIL')
    $('.rbox > div').html('HEAD');

    $('#coin').removeClass();
    $("#coin div:eq(1)").addClass('side-b');
    $('#coin div:eq(0)').addClass('side-a');
    setTimeout(function(){
      if(flipResult <= 0.5){
        $('#coin').addClass('heads');
        globalCoinFlipped = 'head';
        console.log('it is head');
      }
      else{
        $('#coin').addClass('tails');
        globalCoinFlipped = 'tail';
        console.log('it is tails');
      }
    }, 100);
  });*/
});

</script>


</body>
</html>