<?php
require_once('common.php');
$postData = $_POST;

$gmtsec = $postData['gmtsec'];
$user_id = $postData['user_id'];
$screen_size = $postData['screen_size'];
$pxpercm = $postData['pxpercm'];
$current_page = 'step5';


$updated_on = date('Y-m-d H:i:s');
$sql = "UPDATE users SET calibration_submit_time = $gmtsec, px_per_cm = '$pxpercm', screen_size = '$screen_size' , current_page = '$current_page', updated_on =  '$updated_on'  WHERE id = $user_id ";
$mysqli->query($sql);
$mysqli->close();
echo json_encode(array('msg' => 'success', 'data' => array('user_id' =>  $user_id)));
exit;

?>