<?php
require_once('common.php');
//print_r($_POST);

//arra compare

$answer1 = $_POST['answer'][1];
$answer2 = $_POST['answer'][2];
$answer3 = $_POST['answer'][3];
$gmtsec = $_POST['gmtsec'];
$user_id = $_POST['user_id'];


$wrongAnswers = array();
$questions = [1,2,3];
$correct_answers = ['answer1', 'answer1', 'alloftheabove'];
$questionAnswers = array();
$questionAnswers[1][0] = $correct_answers[0];
//$questionAnswers[1][1] = "answer2";
//$questionAnswers[1][2] = "answer4";


$questionAnswers[2][0] =  $correct_answers[1];
//$questionAnswers[2][1] = "answer2";

$questionAnswers[3][0] =  $correct_answers[2];




$answers = $_POST['answer'];

while(count($questions) > 0){
	$index = count($questions);
	if(count($answers[$index]) ===  count($questionAnswers[$index])){
		if( count( array_diff( $questionAnswers[$index],$answers[$index] ) ) !== 0 ){
			$wrongAnswers[]= array($index => array('msg' => "Wrong answer given", "answer" => $questionAnswers[$index]));
		}
	}else{
		$wrongAnswers[]= array($index => array('msg' => "Wrong answer given", "answer" => $questionAnswers[$index]));
	}
	array_pop($questions);
}
if(count($wrongAnswers)){
	$a = json_encode($answers);
	if(!userSubmittedForWrong($user_id)){
		$sql = "INSERT INTO log_of_wrong_answers (user_id, wrong_answers, submitted_on) VALUES ($user_id, '$a' ,$gmtsec);";
		$mysqli->query($sql);
		$mysqli->close();
	}
}

function userSubmittedForWrong($user_id){
	global $mysqli;
	$sql = "SELECT id from log_of_wrong_answers where user_id = $user_id";
	$result = $mysqli->query($sql);
	if($result->num_rows > 0 ) {
		return true;
	}else{
		return false;
	}
}

echo json_encode($wrongAnswers);exit;

?>

