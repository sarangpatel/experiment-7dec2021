<?php

	$dbhost = 'localhost';
	$dbuser = 'root';
	$dbpass = 'root';
	$dbname = 'experiment';

	/*$dbhost = 'localhost';
	$dbuser = 'novapro_novapro';
	$dbpass = 'novapro@123';
	$dbname = 'novapro_campaigns';
	*/

	$mysqli = new mysqli($dbhost, $dbuser, $dbpass, $dbname);
	if($mysqli->connect_errno ) {
		printf("Connect failed: %s<br />", $mysqli->connect_error);
		exit();
	}
	//$mysqli->close();


?>

