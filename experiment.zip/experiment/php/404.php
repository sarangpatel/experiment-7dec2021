<!DOCTYPE html>
<html>
<head>
<style type="text/css">
p {  
	color: blue;    
	font-weight: 900;    
	font-size: 20px;    
	font-family: Helvetica, Arial, sans-serif;    
}

</style>
</head>

<body>

<p>You must be on a computer to complete this task.</p>

</body>
</html>