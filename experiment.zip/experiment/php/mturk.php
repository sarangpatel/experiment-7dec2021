<?php
require_once('common.php');
$postData = $_POST;


array_walk_recursive($postData, function(&$item, $key) {
	$item = addslashes($item);
});

$mturk_id = $postData['mturk_id'];
$gmtsec = $postData['gmtsec'];
$browser = $postData['browser'];
$mousetype = $postData['mousetype'];
$resolution = $postData['resolution'];
$ip = getIP();

//this is the page, where user move to next page, as this step1 is succeed
$current_page = 'step2';


if(($id = user_exists($mturk_id))){
	$user_id = $id;
	$updated_on = date('Y-m-d H:i:s');
	$sql = "UPDATE users SET initialtext_submit_time = '$gmtsec', browser = '$browser' , resolution = '$resolution',
							mousetype= '$mousetype',user_ip = '$ip', current_page = 'step2', updated_on =  '$updated_on' WHERE					 id = $user_id ";
	$mysqli->query($sql);
}else{
	$sql = "INSERT INTO users (mturk_id,initialtext_submit_time, mousetype, resolution, browser, user_ip, user_active,current_page) VALUES 
		('$mturk_id',$gmtsec,'$mousetype', '$resolution', '$browser', '$ip', 1, '$current_page')";
	$mysqli->query($sql);
	$user_id = $mysqli->insert_id;
}
$mysqli->close();
echo json_encode(array('msg' => 'success', 'data' => array('user_id' =>  $user_id)));
exit;

?>