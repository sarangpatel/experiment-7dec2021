<?php
require_once('common.php');
if(!session_id())
session_start();

$postData = $_POST;
$user_id = $postData['user_id'];
$round_no = $postData['round_no'];
$score = $postData['score'];
$session_id = session_id();
$created_on = date('Y-m-d H:i:s');
$sql = "INSERT INTO round_scores (user_id, session_id, round_no, score, created_on) VALUES 
	($user_id,'$session_id', $round_no, $score, '$created_on')";
$mysqli->query($sql);
$mysqli->close();
echo json_encode(array('msg' => 'success', 'data' => array('user_id' =>  $user_id)));
exit;

?>